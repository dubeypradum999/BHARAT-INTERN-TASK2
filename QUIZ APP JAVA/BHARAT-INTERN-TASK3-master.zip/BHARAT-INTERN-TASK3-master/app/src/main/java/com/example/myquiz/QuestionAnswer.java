package com.example.myquiz;

public class QuestionAnswer {
    public static String question[] = {
            "Which company owns the android?",
            "Which one is not the programming language?",
            "Full form of SQL?",
            "Which company owns the Apple?"

    };
    public static String choices[][] = {
            {"Google","Apple","Nokia","Samsung"},
            {"Java","Kotlin","Notepad","Phython"},
            {"Structured Query Language","Start Question Language","Structure Query Line","Structured Query Live"},
            {"Google","Apple","Nokia","Samsung"}

    };
    public static String correctAnswers[] = {
            "Google",
            "Notepad",
            "Structured Query Language",
            "Apple"

    };




}
