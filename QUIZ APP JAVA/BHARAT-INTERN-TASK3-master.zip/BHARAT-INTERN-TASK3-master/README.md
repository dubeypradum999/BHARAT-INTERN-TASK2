# BHARAT-INTERN-TASK3
This is An App Development Project.
In this project  I have created a quiz app.
There are total 4 questions given.
No of questions can be added more.
After selecting the answers of all the above questions
User will get their score.
And there will be a prompt message  of their score.
And after that restart button have been provided  
